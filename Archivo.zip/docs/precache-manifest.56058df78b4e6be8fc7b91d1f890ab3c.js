self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "6e73a4e2d109c3f4a08d07ac540ba749",
    "url": "/index.html"
  },
  {
    "revision": "40633cf930b70a3a5f18",
    "url": "/static/css/main.060df312.chunk.css"
  },
  {
    "revision": "515c332edcdb11022c47",
    "url": "/static/js/2.490abc8f.chunk.js"
  },
  {
    "revision": "fd228f9b9a68ce6b23a6cf8b0a38a0e3",
    "url": "/static/js/2.490abc8f.chunk.js.LICENSE"
  },
  {
    "revision": "40633cf930b70a3a5f18",
    "url": "/static/js/main.222b9caa.chunk.js"
  },
  {
    "revision": "5f07a09bebc73af33ebd",
    "url": "/static/js/runtime-main.374eeb9d.js"
  }
]);