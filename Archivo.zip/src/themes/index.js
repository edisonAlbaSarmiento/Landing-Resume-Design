const theme = {
  color: {
    purple: '#231d2e',
    white: 'white',
    pink: '#ff67b6',
    grayDisabled: '#262138',
    grayText: '#8e8d94',
    purpleMenu: '#281b36',
    overMenu: '#281835',
  }
}

export default theme;